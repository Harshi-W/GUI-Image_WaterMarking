
from tkinter import *
from tkinter import filedialog,messagebox
from PIL import Image, ImageDraw, ImageFont, ImageTk

YELLOW = "#f7f5dd"


def open_image():
    file_path = filedialog.askopenfilename()
    if file_path:
        display_image(file_path)

def display_image(file_path):
    global base
    with Image.open(file_path).convert("RGBA") as base:
        # make a blank image for the text, initialized to transparent text color
        global txt
        txt = Image.new("RGBA", base.size, (255, 255, 255, 0))
        # get a font
        global fnt
        fnt = ImageFont.load_default()
        global frame
        frame = Tk()
        frame.title("TextBox Input")
        frame.geometry('400x200')
        global inputtxt
        inputtxt = Text(frame,
                           height=5,
                           width=20)
        inputtxt.pack()
        input_button = Button(frame, text='Enter', command=show_Image)
        input_button.pack()


def show_Image():
    inp = inputtxt.get(1.0, "end-1c")
    d = ImageDraw.Draw(txt)
    d.text((250, 150), f"{inp}", font=fnt, fill=(220, 207, 214, 1))
    global out
    out = Image.alpha_composite(base, txt)
    out.show()
    # Add a Download button
    download_button = Button(frame, text='Download', command=download_image)
    download_button.pack()


def download_image():
    # Implement code to allow the user to choose a location to save the image
    download_path = filedialog.asksaveasfilename(defaultextension=".jpg", filetypes=[("JPG files", "*.jpg")])

    if download_path:
        rgb_image = out.convert("RGB")
        rgb_image.save(save_path)

    frame.destroy()



window = Tk()
window.title("Image Water-Marking App")
window.config(padx=100,pady=50, background="#f7f5dd")


button_upload = Button(text="Upload an Image", command=open_image)
button_upload.pack()

window.mainloop()